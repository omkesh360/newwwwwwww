'use client';

// Despite most of the components from Chakra has 'use client'
// but for some unknown reasons, it does not work here.
// So we have to manually cover it with re-export like this.
export * from '@chakra-ui/react';
