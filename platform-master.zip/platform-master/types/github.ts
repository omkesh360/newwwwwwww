export type Organization = {
  login: string;
  id: number;
  // node_id: 'MDEyOk9yZ2FuaXphdGlvbjQ4NDE4MzY0',
  // url: 'https://api.github.com/orgs/vuejs-finland',
  // repos_url: 'https://api.github.com/orgs/vuejs-finland/repos',
  // events_url: 'https://api.github.com/orgs/vuejs-finland/events',
  // hooks_url: 'https://api.github.com/orgs/vuejs-finland/hooks',
  // issues_url: 'https://api.github.com/orgs/vuejs-finland/issues',
  // members_url: 'https://api.github.com/orgs/vuejs-finland/members{/member}',
  // public_members_url: 'https://api.github.com/orgs/vuejs-finland/public_members{/member}',
  // avatar_url: 'https://avatars.githubusercontent.com/u/48418364?v=4',
  // description: ''
};
